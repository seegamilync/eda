from eda.event import events
from eda import event
from eda import exc


def get_version():
    return '1.0.0alpha5'
