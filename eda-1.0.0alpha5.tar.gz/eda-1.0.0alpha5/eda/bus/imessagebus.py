

class IMessageBus:
    """Declares the interface for the enterprise message bus."""
