


class UnexpectedEventFormat(AttributeError):
    pass
